
// Impact Custom Link Script

$(document).on('click', "#help_tray a:contains('Canvas Support')", function(event) { 

    window.dispatchEvent(new Event('eesy_launchSupportTab')); 

    event.preventDefault(); 

  } 

);

// BB Ally

window.ALLY_CFG = {
    'baseUrl': 'https://prod.ally.ac',
    'clientId': 12654,
    'lti13Id': '211390000000000112'
};
$.getScript(ALLY_CFG.baseUrl + '/integration/canvas/ally.js');

// End BB Ally

// ReadSpeaker docReader
window.rsConf = {docReader: {}};
// End ReadSpeaker docReader

// ReadSpeaker
(function() {
    jQuery.ajax({
        url: "//cdn-na.readspeaker.com/script/12276/webReaderForEducation/canvas/current/ReadSpeaker.Canvas.js",
        dataType: 'script',
        async: true,
        cache: true
    });
})();

// End ReadSpeaker